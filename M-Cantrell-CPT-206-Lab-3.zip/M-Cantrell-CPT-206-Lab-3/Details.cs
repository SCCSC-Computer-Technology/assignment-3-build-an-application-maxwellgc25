﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M_Cantrell_CPT_206_Lab_3
{
    public partial class Details : Form
    {
        private string stateName = "";

        public Details(string stateSel)
        {
            InitializeComponent();
            //assign state to variable passed from main form
            stateName = stateSel;
        }

        private void Details_Load(object sender, EventArgs e)
        {
            StateInfoLinkDataContext db = new StateInfoLinkDataContext();

            //get state details from database
            var results = from State in db.StateInfos
                          where State.State == stateName
                          select State;

            //assign state details to labels
            foreach (var str in results)
            {
                stateLbl.Text = str.State;
                capLbl.Text = str.Capital;
                popLbl.Text = str.Population.ToString();
                flowerLbl.Text = str.Flower;
                birdLbl.Text = str.Bird;
                cityLbl.Text = str.Largest_Cities;
                colorLbl.Text = str.Colors;
                incomeLbl.Text = str.Median_Income.ToString();
                percLbl.Text = "%" + str.Computer_Jobs____.ToString();
                descriptionLbl.Text = str.Flag_Description;
            }
        }

        //close form to return to main form
        private void closeBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
