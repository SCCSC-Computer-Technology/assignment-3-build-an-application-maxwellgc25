﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M_Cantrell_CPT_206_Lab_3
{
    public partial class Form1 : Form
    {
        //Max Cantrell
        //CPT 206-A80S
        //Lab 3 State Information
        //1-7-25

        public Form1()
        {
            InitializeComponent();
        }

        private void stateInfoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.stateInfoBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.stateListDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'stateListDataSet.StateInfo' table. You can move, or remove it, as needed.
            this.stateInfoTableAdapter.Fill(this.stateListDataSet.StateInfo);
            
            //add states to state details dropdown selection
            foreach (DataRow row in stateListDataSet.Tables["StateInfo"].Rows)
            {
                stateSelectComBox.Items.Add(row["State"].ToString());
            }

        }

        //individual state details function
        private void detailsBtn_Click(object sender, EventArgs e)
        {
            if (stateSelectComBox.SelectedItem != null)
            {
                //get selected state
                string selectedState = stateSelectComBox.SelectedItem.ToString();

                //create the details form and pass selected state
                Details detailsForm = new Details(selectedState);
                detailsForm.Show();
            }
            else
            {
                MessageBox.Show("Please select a state.");

            }
        }

        //search by function
        private void searchBtn_Click(object sender, EventArgs e)
        {
            ResetDataGridView();
            StateInfoLinkDataContext db = new StateInfoLinkDataContext();
            
            //search by state
            if (stateRdBtn.Checked)
            {
                var results = from State in db.StateInfos
                              where State.State.Contains(searchTxtBox.Text)
                              select State;
                stateInfoDataGridView.DataSource = results;
            }
            //search by capital
            else if (capitalRdBtn.Checked)
            {
                var results = from State in db.StateInfos
                              where State.Capital.Contains(searchTxtBox.Text)
                              select State;
                stateInfoDataGridView.DataSource = results;
            }
            //search by flower
            else if (flowerRdBtn.Checked)
            {
                var results = from State in db.StateInfos
                              where State.Flower.Contains(searchTxtBox.Text)
                              select State;
                stateInfoDataGridView.DataSource = results;
            }
            //search by state bird
            else if (birdRdBtn.Checked)
            {
                var results = from State in db.StateInfos
                              where State.Bird.Contains(searchTxtBox.Text)
                              select State;
                stateInfoDataGridView.DataSource = results;
            }
            //search by state colors
            else if (colorsRdBtn.Checked)
            {
                var results = from State in db.StateInfos
                              where State.Colors.Contains(searchTxtBox.Text)
                              select State;
                stateInfoDataGridView.DataSource = results;
            }
            //search by flag description
            else if (flagRdBtn.Checked)
            {
                var results = from State in db.StateInfos
                              where State.Flag_Description.Contains(searchTxtBox.Text)
                              select State;
                stateInfoDataGridView.DataSource = results;
            }
            //search by largest cities
            else if (citiesRdBtn.Checked)
            {
                var results = from State in db.StateInfos
                              where State.Largest_Cities.Contains(searchTxtBox.Text)
                              select State;
                stateInfoDataGridView.DataSource = results;
            }
            //if no search by option selected
            else
            {
                MessageBox.Show("Select a section to search.");
            }

        }

        //filter by function
        private void filterBtn_Click(object sender, EventArgs e)
        {
            ResetDataGridView();
            StateInfoLinkDataContext db = new StateInfoLinkDataContext();
            
            //variable to parse string entered to int
            int filtval = 1;
            int.TryParse(filterTxtBox.Text, out filtval);

            //filter by population
            if (popRdBtn.Checked)
            {
                //equals to text entered
                if(equalsRdBtn.Checked)
                {
                    var results = from State in db.StateInfos
                                  where State.Population == filtval
                                  select State;
                    stateInfoDataGridView.DataSource = results;
                }
                //less than text entered
                else if (lessRdBtn.Checked)
                {
                    var results = from State in db.StateInfos
                                  where State.Population < filtval
                                  select State;
                    stateInfoDataGridView.DataSource = results;
                }
                //greater than text entered
                else if (greaterRdBtn.Checked)
                {
                    var results = from State in db.StateInfos
                                  where State.Population > filtval
                                  select State;
                    stateInfoDataGridView.DataSource = results;
                }
            }
            //filter by median income
            else if (incomeRdBtn.Checked)
            {
                //==
                if (equalsRdBtn.Checked)
                {
                    var results = from State in db.StateInfos
                                  where State.Median_Income == filtval
                                  select State;
                    stateInfoDataGridView.DataSource = results;
                }
                //<
                else if (lessRdBtn.Checked)
                {
                    var results = from State in db.StateInfos
                                  where State.Median_Income < filtval
                                  select State;
                    stateInfoDataGridView.DataSource = results;
                }
                //>
                else if (greaterRdBtn.Checked)
                {
                    var results = from State in db.StateInfos
                                  where State.Median_Income > filtval
                                  select State;
                    stateInfoDataGridView.DataSource = results;
                }
            }
            //filter by percent of computer jobs
            else if (compJobsRdBtn.Checked)
            {
                //==
                if (equalsRdBtn.Checked)
                {
                    var results = from State in db.StateInfos
                                  where State.Computer_Jobs____ == filtval
                                  select State;
                    stateInfoDataGridView.DataSource = results;
                }
                //<
                else if (lessRdBtn.Checked)
                {
                    var results = from State in db.StateInfos
                                  where State.Computer_Jobs____ < filtval
                                  select State;
                    stateInfoDataGridView.DataSource = results;
                }
                //>
                else if (greaterRdBtn.Checked)
                {
                    var results = from State in db.StateInfos
                                  where State.Computer_Jobs____ > filtval
                                  select State;
                    stateInfoDataGridView.DataSource = results;
                }
            }
            //if no filter by selection made
            else
            {
                MessageBox.Show("Please select a field to filter by.");
            }

        }

        //data grid reset, tyring to get blank columns to reappear after initial filter/search
        private void ResetDataGridView()
        {
            stateInfoBindingSource.RemoveFilter();
            this.stateInfoTableAdapter.Fill(this.stateListDataSet.StateInfo);
        }

        //reset main form
        private void clearBtn_Click(object sender, EventArgs e)
        {
            ResetDataGridView();
            stateSelectComBox.SelectedItem = null;
            //clear search group box
            stateRdBtn.Checked = false;
            capitalRdBtn.Checked = false;
            flowerRdBtn.Checked = false;
            birdRdBtn.Checked = false;
            colorsRdBtn.Checked = false;
            flagRdBtn.Checked = false;
            citiesRdBtn.Checked = false;
            searchTxtBox.Text = "";
            //clear filter by group box
            popRdBtn.Checked = false;
            incomeRdBtn.Checked = false;
            compJobsRdBtn.Checked = false;
            equalsRdBtn.Checked = false;
            lessRdBtn.Checked = false;
            greaterRdBtn.Checked = false;
            filterTxtBox.Text = "";
        }
        //close this form
        private void closeBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
