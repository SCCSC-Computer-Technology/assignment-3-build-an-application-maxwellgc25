﻿namespace M_Cantrell_CPT_206_Lab_3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.stateListDataSet = new M_Cantrell_CPT_206_Lab_3.StateListDataSet();
            this.stateInfoBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.stateInfoTableAdapter = new M_Cantrell_CPT_206_Lab_3.StateListDataSetTableAdapters.StateInfoTableAdapter();
            this.tableAdapterManager = new M_Cantrell_CPT_206_Lab_3.StateListDataSetTableAdapters.TableAdapterManager();
            this.stateInfoBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.stateInfoBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.stateInfoDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stateSelectComBox = new System.Windows.Forms.ComboBox();
            this.mainStateLbl = new System.Windows.Forms.Label();
            this.singleStateLbl = new System.Windows.Forms.Label();
            this.detailsBtn = new System.Windows.Forms.Button();
            this.searchByGrpBox = new System.Windows.Forms.GroupBox();
            this.searchTxtBox = new System.Windows.Forms.TextBox();
            this.searchBtn = new System.Windows.Forms.Button();
            this.stateRdBtn = new System.Windows.Forms.RadioButton();
            this.capitalRdBtn = new System.Windows.Forms.RadioButton();
            this.flowerRdBtn = new System.Windows.Forms.RadioButton();
            this.birdRdBtn = new System.Windows.Forms.RadioButton();
            this.colorsRdBtn = new System.Windows.Forms.RadioButton();
            this.filterGrpBox = new System.Windows.Forms.GroupBox();
            this.fieldGrpBox = new System.Windows.Forms.GroupBox();
            this.popRdBtn = new System.Windows.Forms.RadioButton();
            this.incomeRdBtn = new System.Windows.Forms.RadioButton();
            this.compJobsRdBtn = new System.Windows.Forms.RadioButton();
            this.operatorsGrpBox = new System.Windows.Forms.GroupBox();
            this.equalsRdBtn = new System.Windows.Forms.RadioButton();
            this.lessRdBtn = new System.Windows.Forms.RadioButton();
            this.greaterRdBtn = new System.Windows.Forms.RadioButton();
            this.filterTxtBox = new System.Windows.Forms.TextBox();
            this.filterBtn = new System.Windows.Forms.Button();
            this.clearBtn = new System.Windows.Forms.Button();
            this.closeBtn = new System.Windows.Forms.Button();
            this.citiesRdBtn = new System.Windows.Forms.RadioButton();
            this.flagRdBtn = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.stateListDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateInfoBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateInfoBindingNavigator)).BeginInit();
            this.stateInfoBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stateInfoDataGridView)).BeginInit();
            this.searchByGrpBox.SuspendLayout();
            this.filterGrpBox.SuspendLayout();
            this.fieldGrpBox.SuspendLayout();
            this.operatorsGrpBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // stateListDataSet
            // 
            this.stateListDataSet.DataSetName = "StateListDataSet";
            this.stateListDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // stateInfoBindingSource
            // 
            this.stateInfoBindingSource.DataMember = "StateInfo";
            this.stateInfoBindingSource.DataSource = this.stateListDataSet;
            // 
            // stateInfoTableAdapter
            // 
            this.stateInfoTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.StateInfoTableAdapter = this.stateInfoTableAdapter;
            this.tableAdapterManager.UpdateOrder = M_Cantrell_CPT_206_Lab_3.StateListDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // stateInfoBindingNavigator
            // 
            this.stateInfoBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.stateInfoBindingNavigator.BindingSource = this.stateInfoBindingSource;
            this.stateInfoBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.stateInfoBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.stateInfoBindingNavigator.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.stateInfoBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.stateInfoBindingNavigatorSaveItem});
            this.stateInfoBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.stateInfoBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.stateInfoBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.stateInfoBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.stateInfoBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.stateInfoBindingNavigator.Name = "stateInfoBindingNavigator";
            this.stateInfoBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.stateInfoBindingNavigator.Size = new System.Drawing.Size(1457, 38);
            this.stateInfoBindingNavigator.TabIndex = 7;
            this.stateInfoBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(34, 33);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(54, 28);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 33);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 31);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 33);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(34, 28);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 33);
            // 
            // stateInfoBindingNavigatorSaveItem
            // 
            this.stateInfoBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.stateInfoBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("stateInfoBindingNavigatorSaveItem.Image")));
            this.stateInfoBindingNavigatorSaveItem.Name = "stateInfoBindingNavigatorSaveItem";
            this.stateInfoBindingNavigatorSaveItem.Size = new System.Drawing.Size(34, 28);
            this.stateInfoBindingNavigatorSaveItem.Text = "Save Data";
            this.stateInfoBindingNavigatorSaveItem.Click += new System.EventHandler(this.stateInfoBindingNavigatorSaveItem_Click);
            // 
            // stateInfoDataGridView
            // 
            this.stateInfoDataGridView.AutoGenerateColumns = false;
            this.stateInfoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.stateInfoDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11});
            this.stateInfoDataGridView.DataSource = this.stateInfoBindingSource;
            this.stateInfoDataGridView.Location = new System.Drawing.Point(585, 44);
            this.stateInfoDataGridView.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.stateInfoDataGridView.Name = "stateInfoDataGridView";
            this.stateInfoDataGridView.RowHeadersWidth = 62;
            this.stateInfoDataGridView.RowTemplate.Height = 28;
            this.stateInfoDataGridView.Size = new System.Drawing.Size(861, 511);
            this.stateInfoDataGridView.TabIndex = 6;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "StateId";
            this.dataGridViewTextBoxColumn1.HeaderText = "StateId";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "State";
            this.dataGridViewTextBoxColumn2.HeaderText = "State";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 150;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Capital";
            this.dataGridViewTextBoxColumn3.HeaderText = "Capital";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 150;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Population";
            this.dataGridViewTextBoxColumn4.HeaderText = "Population";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.Width = 150;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Flower";
            this.dataGridViewTextBoxColumn5.HeaderText = "Flower";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.Width = 150;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Bird";
            this.dataGridViewTextBoxColumn6.HeaderText = "Bird";
            this.dataGridViewTextBoxColumn6.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.Width = 150;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Largest Cities";
            this.dataGridViewTextBoxColumn7.HeaderText = "Largest Cities";
            this.dataGridViewTextBoxColumn7.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.Width = 150;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Colors";
            this.dataGridViewTextBoxColumn8.HeaderText = "Colors";
            this.dataGridViewTextBoxColumn8.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.Width = 150;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Median Income";
            this.dataGridViewTextBoxColumn9.HeaderText = "Median Income";
            this.dataGridViewTextBoxColumn9.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Width = 150;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Computer Jobs (%)";
            this.dataGridViewTextBoxColumn10.HeaderText = "Computer Jobs (%)";
            this.dataGridViewTextBoxColumn10.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.Width = 150;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Flag Description";
            this.dataGridViewTextBoxColumn11.HeaderText = "Flag Description";
            this.dataGridViewTextBoxColumn11.MinimumWidth = 8;
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.Width = 150;
            // 
            // stateSelectComBox
            // 
            this.stateSelectComBox.FormattingEnabled = true;
            this.stateSelectComBox.Location = new System.Drawing.Point(22, 106);
            this.stateSelectComBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.stateSelectComBox.Name = "stateSelectComBox";
            this.stateSelectComBox.Size = new System.Drawing.Size(209, 28);
            this.stateSelectComBox.TabIndex = 0;
            // 
            // mainStateLbl
            // 
            this.mainStateLbl.AutoSize = true;
            this.mainStateLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mainStateLbl.Location = new System.Drawing.Point(151, 44);
            this.mainStateLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.mainStateLbl.Name = "mainStateLbl";
            this.mainStateLbl.Size = new System.Drawing.Size(210, 29);
            this.mainStateLbl.TabIndex = 8;
            this.mainStateLbl.Text = "State Information";
            // 
            // singleStateLbl
            // 
            this.singleStateLbl.AutoSize = true;
            this.singleStateLbl.Location = new System.Drawing.Point(142, 79);
            this.singleStateLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.singleStateLbl.Name = "singleStateLbl";
            this.singleStateLbl.Size = new System.Drawing.Size(174, 20);
            this.singleStateLbl.TabIndex = 9;
            this.singleStateLbl.Text = "Single State Details:";
            // 
            // detailsBtn
            // 
            this.detailsBtn.Location = new System.Drawing.Point(243, 106);
            this.detailsBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.detailsBtn.Name = "detailsBtn";
            this.detailsBtn.Size = new System.Drawing.Size(216, 32);
            this.detailsBtn.TabIndex = 1;
            this.detailsBtn.Text = "D&isplay State Details";
            this.detailsBtn.UseVisualStyleBackColor = true;
            this.detailsBtn.Click += new System.EventHandler(this.detailsBtn_Click);
            // 
            // searchByGrpBox
            // 
            this.searchByGrpBox.Controls.Add(this.flagRdBtn);
            this.searchByGrpBox.Controls.Add(this.citiesRdBtn);
            this.searchByGrpBox.Controls.Add(this.colorsRdBtn);
            this.searchByGrpBox.Controls.Add(this.birdRdBtn);
            this.searchByGrpBox.Controls.Add(this.flowerRdBtn);
            this.searchByGrpBox.Controls.Add(this.capitalRdBtn);
            this.searchByGrpBox.Controls.Add(this.stateRdBtn);
            this.searchByGrpBox.Controls.Add(this.searchBtn);
            this.searchByGrpBox.Controls.Add(this.searchTxtBox);
            this.searchByGrpBox.Location = new System.Drawing.Point(14, 144);
            this.searchByGrpBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.searchByGrpBox.Name = "searchByGrpBox";
            this.searchByGrpBox.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.searchByGrpBox.Size = new System.Drawing.Size(542, 126);
            this.searchByGrpBox.TabIndex = 2;
            this.searchByGrpBox.TabStop = false;
            this.searchByGrpBox.Text = "Search By:";
            // 
            // searchTxtBox
            // 
            this.searchTxtBox.Location = new System.Drawing.Point(15, 78);
            this.searchTxtBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.searchTxtBox.Name = "searchTxtBox";
            this.searchTxtBox.Size = new System.Drawing.Size(189, 26);
            this.searchTxtBox.TabIndex = 6;
            // 
            // searchBtn
            // 
            this.searchBtn.Location = new System.Drawing.Point(225, 78);
            this.searchBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(135, 30);
            this.searchBtn.TabIndex = 7;
            this.searchBtn.Text = "S&earch";
            this.searchBtn.UseVisualStyleBackColor = true;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // stateRdBtn
            // 
            this.stateRdBtn.AutoSize = true;
            this.stateRdBtn.Location = new System.Drawing.Point(8, 34);
            this.stateRdBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.stateRdBtn.Name = "stateRdBtn";
            this.stateRdBtn.Size = new System.Drawing.Size(78, 24);
            this.stateRdBtn.TabIndex = 0;
            this.stateRdBtn.TabStop = true;
            this.stateRdBtn.Text = "State";
            this.stateRdBtn.UseVisualStyleBackColor = true;
            // 
            // capitalRdBtn
            // 
            this.capitalRdBtn.AutoSize = true;
            this.capitalRdBtn.Location = new System.Drawing.Point(95, 34);
            this.capitalRdBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.capitalRdBtn.Name = "capitalRdBtn";
            this.capitalRdBtn.Size = new System.Drawing.Size(90, 24);
            this.capitalRdBtn.TabIndex = 1;
            this.capitalRdBtn.TabStop = true;
            this.capitalRdBtn.Text = "Capital";
            this.capitalRdBtn.UseVisualStyleBackColor = true;
            // 
            // flowerRdBtn
            // 
            this.flowerRdBtn.AutoSize = true;
            this.flowerRdBtn.Location = new System.Drawing.Point(195, 34);
            this.flowerRdBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.flowerRdBtn.Name = "flowerRdBtn";
            this.flowerRdBtn.Size = new System.Drawing.Size(87, 24);
            this.flowerRdBtn.TabIndex = 2;
            this.flowerRdBtn.TabStop = true;
            this.flowerRdBtn.Text = "Flower";
            this.flowerRdBtn.UseVisualStyleBackColor = true;
            // 
            // birdRdBtn
            // 
            this.birdRdBtn.AutoSize = true;
            this.birdRdBtn.Location = new System.Drawing.Point(291, 34);
            this.birdRdBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.birdRdBtn.Name = "birdRdBtn";
            this.birdRdBtn.Size = new System.Drawing.Size(66, 24);
            this.birdRdBtn.TabIndex = 3;
            this.birdRdBtn.TabStop = true;
            this.birdRdBtn.Text = "Bird";
            this.birdRdBtn.UseVisualStyleBackColor = true;
            // 
            // colorsRdBtn
            // 
            this.colorsRdBtn.AutoSize = true;
            this.colorsRdBtn.Location = new System.Drawing.Point(364, 34);
            this.colorsRdBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.colorsRdBtn.Name = "colorsRdBtn";
            this.colorsRdBtn.Size = new System.Drawing.Size(85, 24);
            this.colorsRdBtn.TabIndex = 4;
            this.colorsRdBtn.TabStop = true;
            this.colorsRdBtn.Text = "Colors";
            this.colorsRdBtn.UseVisualStyleBackColor = true;
            // 
            // filterGrpBox
            // 
            this.filterGrpBox.Controls.Add(this.filterBtn);
            this.filterGrpBox.Controls.Add(this.filterTxtBox);
            this.filterGrpBox.Controls.Add(this.operatorsGrpBox);
            this.filterGrpBox.Controls.Add(this.fieldGrpBox);
            this.filterGrpBox.Location = new System.Drawing.Point(14, 275);
            this.filterGrpBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.filterGrpBox.Name = "filterGrpBox";
            this.filterGrpBox.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.filterGrpBox.Size = new System.Drawing.Size(505, 232);
            this.filterGrpBox.TabIndex = 3;
            this.filterGrpBox.TabStop = false;
            this.filterGrpBox.Text = "Filter By:";
            // 
            // fieldGrpBox
            // 
            this.fieldGrpBox.Controls.Add(this.compJobsRdBtn);
            this.fieldGrpBox.Controls.Add(this.incomeRdBtn);
            this.fieldGrpBox.Controls.Add(this.popRdBtn);
            this.fieldGrpBox.Location = new System.Drawing.Point(6, 25);
            this.fieldGrpBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.fieldGrpBox.Name = "fieldGrpBox";
            this.fieldGrpBox.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.fieldGrpBox.Size = new System.Drawing.Size(491, 65);
            this.fieldGrpBox.TabIndex = 0;
            this.fieldGrpBox.TabStop = false;
            this.fieldGrpBox.Text = "Field";
            // 
            // popRdBtn
            // 
            this.popRdBtn.AutoSize = true;
            this.popRdBtn.Location = new System.Drawing.Point(18, 30);
            this.popRdBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.popRdBtn.Name = "popRdBtn";
            this.popRdBtn.Size = new System.Drawing.Size(119, 24);
            this.popRdBtn.TabIndex = 0;
            this.popRdBtn.TabStop = true;
            this.popRdBtn.Text = "Population";
            this.popRdBtn.UseVisualStyleBackColor = true;
            // 
            // incomeRdBtn
            // 
            this.incomeRdBtn.AutoSize = true;
            this.incomeRdBtn.Location = new System.Drawing.Point(145, 30);
            this.incomeRdBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.incomeRdBtn.Name = "incomeRdBtn";
            this.incomeRdBtn.Size = new System.Drawing.Size(156, 24);
            this.incomeRdBtn.TabIndex = 1;
            this.incomeRdBtn.TabStop = true;
            this.incomeRdBtn.Text = "Median Income";
            this.incomeRdBtn.UseVisualStyleBackColor = true;
            // 
            // compJobsRdBtn
            // 
            this.compJobsRdBtn.AutoSize = true;
            this.compJobsRdBtn.Location = new System.Drawing.Point(311, 30);
            this.compJobsRdBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.compJobsRdBtn.Name = "compJobsRdBtn";
            this.compJobsRdBtn.Size = new System.Drawing.Size(155, 24);
            this.compJobsRdBtn.TabIndex = 2;
            this.compJobsRdBtn.TabStop = true;
            this.compJobsRdBtn.Text = "Computer Jobs";
            this.compJobsRdBtn.UseVisualStyleBackColor = true;
            // 
            // operatorsGrpBox
            // 
            this.operatorsGrpBox.Controls.Add(this.greaterRdBtn);
            this.operatorsGrpBox.Controls.Add(this.lessRdBtn);
            this.operatorsGrpBox.Controls.Add(this.equalsRdBtn);
            this.operatorsGrpBox.Location = new System.Drawing.Point(8, 96);
            this.operatorsGrpBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.operatorsGrpBox.Name = "operatorsGrpBox";
            this.operatorsGrpBox.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.operatorsGrpBox.Size = new System.Drawing.Size(490, 66);
            this.operatorsGrpBox.TabIndex = 1;
            this.operatorsGrpBox.TabStop = false;
            this.operatorsGrpBox.Text = "Operators";
            // 
            // equalsRdBtn
            // 
            this.equalsRdBtn.AutoSize = true;
            this.equalsRdBtn.Location = new System.Drawing.Point(25, 26);
            this.equalsRdBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.equalsRdBtn.Name = "equalsRdBtn";
            this.equalsRdBtn.Size = new System.Drawing.Size(116, 24);
            this.equalsRdBtn.TabIndex = 0;
            this.equalsRdBtn.TabStop = true;
            this.equalsRdBtn.Text = "Equals (=)";
            this.equalsRdBtn.UseVisualStyleBackColor = true;
            // 
            // lessRdBtn
            // 
            this.lessRdBtn.AutoSize = true;
            this.lessRdBtn.Location = new System.Drawing.Point(150, 26);
            this.lessRdBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.lessRdBtn.Name = "lessRdBtn";
            this.lessRdBtn.Size = new System.Drawing.Size(144, 24);
            this.lessRdBtn.TabIndex = 1;
            this.lessRdBtn.TabStop = true;
            this.lessRdBtn.Text = "Less Than (<)";
            this.lessRdBtn.UseVisualStyleBackColor = true;
            // 
            // greaterRdBtn
            // 
            this.greaterRdBtn.AutoSize = true;
            this.greaterRdBtn.Location = new System.Drawing.Point(302, 26);
            this.greaterRdBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.greaterRdBtn.Name = "greaterRdBtn";
            this.greaterRdBtn.Size = new System.Drawing.Size(168, 24);
            this.greaterRdBtn.TabIndex = 2;
            this.greaterRdBtn.TabStop = true;
            this.greaterRdBtn.Text = "Greater Than (>)";
            this.greaterRdBtn.UseVisualStyleBackColor = true;
            // 
            // filterTxtBox
            // 
            this.filterTxtBox.Location = new System.Drawing.Point(15, 187);
            this.filterTxtBox.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.filterTxtBox.Name = "filterTxtBox";
            this.filterTxtBox.Size = new System.Drawing.Size(284, 26);
            this.filterTxtBox.TabIndex = 2;
            // 
            // filterBtn
            // 
            this.filterBtn.Location = new System.Drawing.Point(335, 187);
            this.filterBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.filterBtn.Name = "filterBtn";
            this.filterBtn.Size = new System.Drawing.Size(114, 32);
            this.filterBtn.TabIndex = 3;
            this.filterBtn.Text = "F&ilter";
            this.filterBtn.UseVisualStyleBackColor = true;
            this.filterBtn.Click += new System.EventHandler(this.filterBtn_Click);
            // 
            // clearBtn
            // 
            this.clearBtn.Location = new System.Drawing.Point(95, 523);
            this.clearBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.clearBtn.Name = "clearBtn";
            this.clearBtn.Size = new System.Drawing.Size(135, 35);
            this.clearBtn.TabIndex = 4;
            this.clearBtn.Text = "R&eset";
            this.clearBtn.UseVisualStyleBackColor = true;
            this.clearBtn.Click += new System.EventHandler(this.clearBtn_Click);
            // 
            // closeBtn
            // 
            this.closeBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.closeBtn.Location = new System.Drawing.Point(305, 523);
            this.closeBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(135, 35);
            this.closeBtn.TabIndex = 5;
            this.closeBtn.Text = "E&xit";
            this.closeBtn.UseVisualStyleBackColor = true;
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // citiesRdBtn
            // 
            this.citiesRdBtn.AutoSize = true;
            this.citiesRdBtn.Location = new System.Drawing.Point(395, 81);
            this.citiesRdBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.citiesRdBtn.Name = "citiesRdBtn";
            this.citiesRdBtn.Size = new System.Drawing.Size(130, 24);
            this.citiesRdBtn.TabIndex = 8;
            this.citiesRdBtn.TabStop = true;
            this.citiesRdBtn.Text = "Large Cities";
            this.citiesRdBtn.UseVisualStyleBackColor = true;
            // 
            // flagRdBtn
            // 
            this.flagRdBtn.AutoSize = true;
            this.flagRdBtn.Location = new System.Drawing.Point(458, 34);
            this.flagRdBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.flagRdBtn.Name = "flagRdBtn";
            this.flagRdBtn.Size = new System.Drawing.Size(69, 24);
            this.flagRdBtn.TabIndex = 5;
            this.flagRdBtn.TabStop = true;
            this.flagRdBtn.Text = "Flag";
            this.flagRdBtn.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AcceptButton = this.clearBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CancelButton = this.closeBtn;
            this.ClientSize = new System.Drawing.Size(1457, 565);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.clearBtn);
            this.Controls.Add(this.filterGrpBox);
            this.Controls.Add(this.searchByGrpBox);
            this.Controls.Add(this.detailsBtn);
            this.Controls.Add(this.singleStateLbl);
            this.Controls.Add(this.mainStateLbl);
            this.Controls.Add(this.stateSelectComBox);
            this.Controls.Add(this.stateInfoDataGridView);
            this.Controls.Add(this.stateInfoBindingNavigator);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MCantrell-206-Lab-3-State-Information";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.stateListDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateInfoBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.stateInfoBindingNavigator)).EndInit();
            this.stateInfoBindingNavigator.ResumeLayout(false);
            this.stateInfoBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stateInfoDataGridView)).EndInit();
            this.searchByGrpBox.ResumeLayout(false);
            this.searchByGrpBox.PerformLayout();
            this.filterGrpBox.ResumeLayout(false);
            this.filterGrpBox.PerformLayout();
            this.fieldGrpBox.ResumeLayout(false);
            this.fieldGrpBox.PerformLayout();
            this.operatorsGrpBox.ResumeLayout(false);
            this.operatorsGrpBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private StateListDataSet stateListDataSet;
        private System.Windows.Forms.BindingSource stateInfoBindingSource;
        private StateListDataSetTableAdapters.StateInfoTableAdapter stateInfoTableAdapter;
        private StateListDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator stateInfoBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton stateInfoBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView stateInfoDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.ComboBox stateSelectComBox;
        private System.Windows.Forms.Label mainStateLbl;
        private System.Windows.Forms.Label singleStateLbl;
        private System.Windows.Forms.Button detailsBtn;
        private System.Windows.Forms.GroupBox searchByGrpBox;
        private System.Windows.Forms.RadioButton birdRdBtn;
        private System.Windows.Forms.RadioButton flowerRdBtn;
        private System.Windows.Forms.RadioButton capitalRdBtn;
        private System.Windows.Forms.RadioButton stateRdBtn;
        private System.Windows.Forms.Button searchBtn;
        private System.Windows.Forms.TextBox searchTxtBox;
        private System.Windows.Forms.RadioButton colorsRdBtn;
        private System.Windows.Forms.GroupBox filterGrpBox;
        private System.Windows.Forms.GroupBox fieldGrpBox;
        private System.Windows.Forms.RadioButton incomeRdBtn;
        private System.Windows.Forms.RadioButton popRdBtn;
        private System.Windows.Forms.Button filterBtn;
        private System.Windows.Forms.TextBox filterTxtBox;
        private System.Windows.Forms.GroupBox operatorsGrpBox;
        private System.Windows.Forms.RadioButton greaterRdBtn;
        private System.Windows.Forms.RadioButton lessRdBtn;
        private System.Windows.Forms.RadioButton equalsRdBtn;
        private System.Windows.Forms.RadioButton compJobsRdBtn;
        private System.Windows.Forms.Button clearBtn;
        private System.Windows.Forms.Button closeBtn;
        private System.Windows.Forms.RadioButton flagRdBtn;
        private System.Windows.Forms.RadioButton citiesRdBtn;
    }
}

