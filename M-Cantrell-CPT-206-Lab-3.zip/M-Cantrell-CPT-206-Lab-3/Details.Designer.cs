﻿namespace M_Cantrell_CPT_206_Lab_3
{
    partial class Details
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.stateTLbl = new System.Windows.Forms.Label();
            this.capTLbl = new System.Windows.Forms.Label();
            this.popTlbl = new System.Windows.Forms.Label();
            this.flowerTLbl = new System.Windows.Forms.Label();
            this.birdTLbl = new System.Windows.Forms.Label();
            this.citiesTLbl = new System.Windows.Forms.Label();
            this.colorsTLbl = new System.Windows.Forms.Label();
            this.incomeTLbl = new System.Windows.Forms.Label();
            this.compTLbl = new System.Windows.Forms.Label();
            this.stateLbl = new System.Windows.Forms.Label();
            this.flagTLbl = new System.Windows.Forms.Label();
            this.capLbl = new System.Windows.Forms.Label();
            this.popLbl = new System.Windows.Forms.Label();
            this.flowerLbl = new System.Windows.Forms.Label();
            this.birdLbl = new System.Windows.Forms.Label();
            this.cityLbl = new System.Windows.Forms.Label();
            this.colorLbl = new System.Windows.Forms.Label();
            this.incomeLbl = new System.Windows.Forms.Label();
            this.percLbl = new System.Windows.Forms.Label();
            this.descriptionLbl = new System.Windows.Forms.Label();
            this.closeBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // stateTLbl
            // 
            this.stateTLbl.AutoSize = true;
            this.stateTLbl.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stateTLbl.Location = new System.Drawing.Point(362, 9);
            this.stateTLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.stateTLbl.Name = "stateTLbl";
            this.stateTLbl.Size = new System.Drawing.Size(83, 32);
            this.stateTLbl.TabIndex = 0;
            this.stateTLbl.Text = "State:";
            // 
            // capTLbl
            // 
            this.capTLbl.AutoSize = true;
            this.capTLbl.Location = new System.Drawing.Point(20, 57);
            this.capTLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.capTLbl.Name = "capTLbl";
            this.capTLbl.Size = new System.Drawing.Size(115, 20);
            this.capTLbl.TabIndex = 1;
            this.capTLbl.Text = "State Capital:";
            // 
            // popTlbl
            // 
            this.popTlbl.AutoSize = true;
            this.popTlbl.Location = new System.Drawing.Point(20, 84);
            this.popTlbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.popTlbl.Name = "popTlbl";
            this.popTlbl.Size = new System.Drawing.Size(100, 20);
            this.popTlbl.TabIndex = 2;
            this.popTlbl.Text = "Population:";
            // 
            // flowerTLbl
            // 
            this.flowerTLbl.AutoSize = true;
            this.flowerTLbl.Location = new System.Drawing.Point(20, 114);
            this.flowerTLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.flowerTLbl.Name = "flowerTLbl";
            this.flowerTLbl.Size = new System.Drawing.Size(110, 20);
            this.flowerTLbl.TabIndex = 3;
            this.flowerTLbl.Text = "State Flower:";
            // 
            // birdTLbl
            // 
            this.birdTLbl.AutoSize = true;
            this.birdTLbl.Location = new System.Drawing.Point(20, 145);
            this.birdTLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.birdTLbl.Name = "birdTLbl";
            this.birdTLbl.Size = new System.Drawing.Size(92, 20);
            this.birdTLbl.TabIndex = 4;
            this.birdTLbl.Text = "State Bird:";
            // 
            // citiesTLbl
            // 
            this.citiesTLbl.AutoSize = true;
            this.citiesTLbl.Location = new System.Drawing.Point(21, 176);
            this.citiesTLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.citiesTLbl.Name = "citiesTLbl";
            this.citiesTLbl.Size = new System.Drawing.Size(135, 20);
            this.citiesTLbl.TabIndex = 5;
            this.citiesTLbl.Text = "3 Largest Cities:";
            // 
            // colorsTLbl
            // 
            this.colorsTLbl.AutoSize = true;
            this.colorsTLbl.Location = new System.Drawing.Point(21, 205);
            this.colorsTLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.colorsTLbl.Name = "colorsTLbl";
            this.colorsTLbl.Size = new System.Drawing.Size(110, 20);
            this.colorsTLbl.TabIndex = 6;
            this.colorsTLbl.Text = "State Colors:";
            // 
            // incomeTLbl
            // 
            this.incomeTLbl.AutoSize = true;
            this.incomeTLbl.Location = new System.Drawing.Point(20, 238);
            this.incomeTLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.incomeTLbl.Name = "incomeTLbl";
            this.incomeTLbl.Size = new System.Drawing.Size(136, 20);
            this.incomeTLbl.TabIndex = 7;
            this.incomeTLbl.Text = "Median Income:";
            // 
            // compTLbl
            // 
            this.compTLbl.AutoSize = true;
            this.compTLbl.Location = new System.Drawing.Point(20, 268);
            this.compTLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.compTLbl.Name = "compTLbl";
            this.compTLbl.Size = new System.Drawing.Size(282, 20);
            this.compTLbl.TabIndex = 8;
            this.compTLbl.Text = "Percent of Computer Related Jobs:";
            // 
            // stateLbl
            // 
            this.stateLbl.AutoSize = true;
            this.stateLbl.Font = new System.Drawing.Font("Times New Roman", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.stateLbl.Location = new System.Drawing.Point(431, 9);
            this.stateLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.stateLbl.Name = "stateLbl";
            this.stateLbl.Size = new System.Drawing.Size(134, 32);
            this.stateLbl.TabIndex = 9;
            this.stateLbl.Text = "This State";
            // 
            // flagTLbl
            // 
            this.flagTLbl.AutoSize = true;
            this.flagTLbl.Location = new System.Drawing.Point(381, 53);
            this.flagTLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.flagTLbl.Name = "flagTLbl";
            this.flagTLbl.Size = new System.Drawing.Size(185, 20);
            this.flagTLbl.TabIndex = 10;
            this.flagTLbl.Text = "State Flag Description:";
            // 
            // capLbl
            // 
            this.capLbl.AutoSize = true;
            this.capLbl.Location = new System.Drawing.Point(131, 56);
            this.capLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.capLbl.Name = "capLbl";
            this.capLbl.Size = new System.Drawing.Size(66, 20);
            this.capLbl.TabIndex = 11;
            this.capLbl.Text = "Capital";
            // 
            // popLbl
            // 
            this.popLbl.AutoSize = true;
            this.popLbl.Location = new System.Drawing.Point(117, 83);
            this.popLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.popLbl.Name = "popLbl";
            this.popLbl.Size = new System.Drawing.Size(95, 20);
            this.popLbl.TabIndex = 12;
            this.popLbl.Text = "Population";
            // 
            // flowerLbl
            // 
            this.flowerLbl.AutoSize = true;
            this.flowerLbl.Location = new System.Drawing.Point(130, 114);
            this.flowerLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.flowerLbl.Name = "flowerLbl";
            this.flowerLbl.Size = new System.Drawing.Size(61, 20);
            this.flowerLbl.TabIndex = 13;
            this.flowerLbl.Text = "Flower";
            // 
            // birdLbl
            // 
            this.birdLbl.AutoSize = true;
            this.birdLbl.Location = new System.Drawing.Point(112, 144);
            this.birdLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.birdLbl.Name = "birdLbl";
            this.birdLbl.Size = new System.Drawing.Size(43, 20);
            this.birdLbl.TabIndex = 14;
            this.birdLbl.Text = "Bird";
            // 
            // cityLbl
            // 
            this.cityLbl.AutoSize = true;
            this.cityLbl.Location = new System.Drawing.Point(155, 175);
            this.cityLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.cityLbl.Name = "cityLbl";
            this.cityLbl.Size = new System.Drawing.Size(53, 20);
            this.cityLbl.TabIndex = 15;
            this.cityLbl.Text = "Cities";
            // 
            // colorLbl
            // 
            this.colorLbl.AutoSize = true;
            this.colorLbl.Location = new System.Drawing.Point(129, 205);
            this.colorLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.colorLbl.Name = "colorLbl";
            this.colorLbl.Size = new System.Drawing.Size(61, 20);
            this.colorLbl.TabIndex = 16;
            this.colorLbl.Text = "Colors";
            // 
            // incomeLbl
            // 
            this.incomeLbl.AutoSize = true;
            this.incomeLbl.Location = new System.Drawing.Point(159, 238);
            this.incomeLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.incomeLbl.Name = "incomeLbl";
            this.incomeLbl.Size = new System.Drawing.Size(67, 20);
            this.incomeLbl.TabIndex = 17;
            this.incomeLbl.Text = "Income";
            // 
            // percLbl
            // 
            this.percLbl.AutoSize = true;
            this.percLbl.Location = new System.Drawing.Point(310, 268);
            this.percLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.percLbl.Name = "percLbl";
            this.percLbl.Size = new System.Drawing.Size(67, 20);
            this.percLbl.TabIndex = 18;
            this.percLbl.Text = "Percent";
            // 
            // descriptionLbl
            // 
            this.descriptionLbl.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.descriptionLbl.Location = new System.Drawing.Point(385, 83);
            this.descriptionLbl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.descriptionLbl.Name = "descriptionLbl";
            this.descriptionLbl.Size = new System.Drawing.Size(555, 314);
            this.descriptionLbl.TabIndex = 19;
            this.descriptionLbl.Text = "State Flag";
            // 
            // closeBtn
            // 
            this.closeBtn.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.closeBtn.Location = new System.Drawing.Point(345, 417);
            this.closeBtn.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.closeBtn.Name = "closeBtn";
            this.closeBtn.Size = new System.Drawing.Size(260, 38);
            this.closeBtn.TabIndex = 20;
            this.closeBtn.Text = "Back To State Data";
            this.closeBtn.UseVisualStyleBackColor = true;
            this.closeBtn.Click += new System.EventHandler(this.closeBtn_Click);
            // 
            // Details
            // 
            this.AcceptButton = this.closeBtn;
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.CancelButton = this.closeBtn;
            this.ClientSize = new System.Drawing.Size(953, 468);
            this.Controls.Add(this.closeBtn);
            this.Controls.Add(this.descriptionLbl);
            this.Controls.Add(this.percLbl);
            this.Controls.Add(this.incomeLbl);
            this.Controls.Add(this.colorLbl);
            this.Controls.Add(this.cityLbl);
            this.Controls.Add(this.birdLbl);
            this.Controls.Add(this.flowerLbl);
            this.Controls.Add(this.popLbl);
            this.Controls.Add(this.capLbl);
            this.Controls.Add(this.flagTLbl);
            this.Controls.Add(this.stateLbl);
            this.Controls.Add(this.compTLbl);
            this.Controls.Add(this.incomeTLbl);
            this.Controls.Add(this.colorsTLbl);
            this.Controls.Add(this.citiesTLbl);
            this.Controls.Add(this.birdTLbl);
            this.Controls.Add(this.flowerTLbl);
            this.Controls.Add(this.popTlbl);
            this.Controls.Add(this.capTLbl);
            this.Controls.Add(this.stateTLbl);
            this.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Details";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "State Details";
            this.Load += new System.EventHandler(this.Details_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label stateTLbl;
        private System.Windows.Forms.Label capTLbl;
        private System.Windows.Forms.Label popTlbl;
        private System.Windows.Forms.Label flowerTLbl;
        private System.Windows.Forms.Label birdTLbl;
        private System.Windows.Forms.Label citiesTLbl;
        private System.Windows.Forms.Label colorsTLbl;
        private System.Windows.Forms.Label incomeTLbl;
        private System.Windows.Forms.Label compTLbl;
        private System.Windows.Forms.Label stateLbl;
        private System.Windows.Forms.Label flagTLbl;
        private System.Windows.Forms.Label capLbl;
        private System.Windows.Forms.Label popLbl;
        private System.Windows.Forms.Label flowerLbl;
        private System.Windows.Forms.Label birdLbl;
        private System.Windows.Forms.Label cityLbl;
        private System.Windows.Forms.Label colorLbl;
        private System.Windows.Forms.Label incomeLbl;
        private System.Windows.Forms.Label percLbl;
        private System.Windows.Forms.Label descriptionLbl;
        private System.Windows.Forms.Button closeBtn;
    }
}